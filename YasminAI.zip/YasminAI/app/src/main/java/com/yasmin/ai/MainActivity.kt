@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.yasmin.ai

import android.Manifest
import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.app.SearchManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Path
import android.graphics.Rect
import android.media.AudioManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.AlarmClock
import android.provider.CalendarContract
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.view.KeyEvent
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.sin

/* ============================================================
   YASMIN AI  -  single-file app (UI + Gemini + voice + memory + phone control)
   Sections:
   1. Data classes & Prefs (settings + memory storage)
   2. Gemini REST client
   3. Accessibility service (phone control)
   4. MainActivity (voice, brain, actions)
   5. Compose UI (orb, waveform, chat, settings)
   ============================================================ */

// ---------- 1. DATA & PREFS ----------

enum class Status { IDLE, LISTENING, THINKING, SPEAKING }
enum class ListenMode { OFF, WAKE, CONVO, ONESHOT }

data class Msg(val fromUser: Boolean, val text: String)
data class Parsed(val reply: String, val speech: String, val actions: List<Triple<String, String, String>>)

class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("yasmin_prefs", Context.MODE_PRIVATE)

    var apiKey by mutableStateOf(sp.getString("apiKey", "") ?: "")
    var model by mutableStateOf(sp.getString("model", "gemini-2.5-flash") ?: "gemini-2.5-flash")
    var voiceName by mutableStateOf(sp.getString("voiceName", "") ?: "")
    var rate by mutableStateOf(sp.getFloat("rate", 1.0f))
    var pitch by mutableStateOf(sp.getFloat("pitch", 1.15f))
    var wake by mutableStateOf(sp.getBoolean("wake", true))
    var lang by mutableStateOf(sp.getString("lang", "hi-IN") ?: "hi-IN")
    var memory by mutableStateOf(sp.getBoolean("memory", true))
    var theme by mutableStateOf(sp.getString("theme", "Purple") ?: "Purple")
    var personality by mutableStateOf(sp.getString("personality", "Loving") ?: "Loving")
    var userName by mutableStateOf(sp.getString("userName", "") ?: "")
    var customPrompt by mutableStateOf(sp.getString("customPrompt", "") ?: "")
    var phoneControl by mutableStateOf(sp.getBoolean("phoneControl", true))
    var screenReading by mutableStateOf(sp.getBoolean("screenReading", true))

    fun save() {
        sp.edit()
            .putString("apiKey", apiKey)
            .putString("model", model)
            .putString("voiceName", voiceName)
            .putFloat("rate", rate)
            .putFloat("pitch", pitch)
            .putBoolean("wake", wake)
            .putString("lang", lang)
            .putBoolean("memory", memory)
            .putString("theme", theme)
            .putString("personality", personality)
            .putString("userName", userName)
            .putString("customPrompt", customPrompt)
            .putBoolean("phoneControl", phoneControl)
            .putBoolean("screenReading", screenReading)
            .apply()
    }

    private fun readList(k: String): MutableList<String> {
        val a = try { JSONArray(sp.getString(k, "[]")) } catch (e: Exception) { JSONArray() }
        return MutableList(a.length()) { a.getString(it) }
    }

    private fun writeList(k: String, l: List<String>) {
        sp.edit().putString(k, JSONArray(l).toString()).apply()
    }

    fun facts(): List<String> = readList("facts")
    fun addFact(f: String) { val l = readList("facts"); l.add(f); writeList("facts", l.takeLast(200)) }
    fun clearFacts() { writeList("facts", emptyList()) }

    fun notes(): List<String> = readList("notes")
    fun addNote(n: String) { val l = readList("notes"); l.add(n); writeList("notes", l.takeLast(500)) }

    fun loadHistory(): List<Msg> {
        val a = try { JSONArray(sp.getString("history", "[]")) } catch (e: Exception) { JSONArray() }
        return List(a.length()) {
            val o = a.getJSONObject(it)
            Msg(o.getBoolean("u"), o.getString("t"))
        }
    }

    fun saveHistory(l: List<Msg>) {
        val a = JSONArray()
        l.takeLast(100).forEach { a.put(JSONObject().put("u", it.fromUser).put("t", it.text)) }
        sp.edit().putString("history", a.toString()).apply()
    }

    fun clearHistory() { sp.edit().putString("history", "[]").apply() }
}

// ---------- 2. GEMINI CLIENT ----------

object GeminiClient {
    /** turns = list of (role, text) where role is "user" or "model". Blocking: call from IO thread. */
    fun generate(key: String, model: String, system: String, turns: List<Pair<String, String>>): String {
        val body = JSONObject()
        body.put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
        val contents = JSONArray()
        for ((role, text) in turns) {
            contents.put(
                JSONObject().put("role", role)
                    .put("parts", JSONArray().put(JSONObject().put("text", text)))
            )
        }
        body.put("contents", contents)
        body.put(
            "generationConfig",
            JSONObject().put("responseMimeType", "application/json").put("temperature", 0.9)
        )
        val conn = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
            .openConnection() as HttpURLConnection
        conn.requestMethod = "POST"
        conn.setRequestProperty("Content-Type", "application/json")
        conn.setRequestProperty("x-goog-api-key", key)
        conn.connectTimeout = 20000
        conn.readTimeout = 60000
        conn.doOutput = true
        conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
        if (code !in 200..299) {
            val msg = try {
                JSONObject(text).getJSONObject("error").getString("message")
            } catch (e: Exception) {
                text.take(200)
            }
            throw Exception("Gemini $code: $msg")
        }
        val parts = JSONObject(text).getJSONArray("candidates").getJSONObject(0)
            .getJSONObject("content").getJSONArray("parts")
        val sb = StringBuilder()
        for (i in 0 until parts.length()) sb.append(parts.getJSONObject(i).optString("text"))
        return sb.toString()
    }
}

// ---------- 3. ACCESSIBILITY SERVICE (PHONE CONTROL) ----------

class YasminAccessibilityService : AccessibilityService() {
    companion object {
        @Volatile
        var instance: YasminAccessibilityService? = null
    }

    override fun onServiceConnected() { instance = this }
    override fun onUnbind(intent: Intent?): Boolean { instance = null; return super.onUnbind(intent) }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    private val w get() = resources.displayMetrics.widthPixels.toFloat()
    private val h get() = resources.displayMetrics.heightPixels.toFloat()

    fun back() = performGlobalAction(GLOBAL_ACTION_BACK)
    fun home() = performGlobalAction(GLOBAL_ACTION_HOME)

    private fun swipe(x1: Float, y1: Float, x2: Float, y2: Float, dur: Long = 300): Boolean {
        val p = Path().apply { moveTo(x1, y1); lineTo(x2, y2) }
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(p, 0, dur)).build()
        return dispatchGesture(g, null, null)
    }

    fun tap(x: Float, y: Float): Boolean {
        val p = Path().apply { moveTo(x, y) }
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(p, 0, 60)).build()
        return dispatchGesture(g, null, null)
    }

    /** finger swipes UP: shows later content / next Reel */
    fun scrollDown() = swipe(w / 2, h * 0.75f, w / 2, h * 0.25f)
    fun scrollUp() = swipe(w / 2, h * 0.25f, w / 2, h * 0.75f)
    fun swipeLeft() = swipe(w * 0.85f, h / 2, w * 0.15f, h / 2)
    fun swipeRight() = swipe(w * 0.15f, h / 2, w * 0.85f, h / 2)

    fun clickByText(t: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val nodes = root.findAccessibilityNodeInfosByText(t)
        for (n in nodes) {
            var cur: AccessibilityNodeInfo? = n
            while (cur != null) {
                if (cur.isClickable && cur.isEnabled) {
                    if (cur.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
                }
                cur = cur.parent
            }
            val r = Rect()
            n.getBoundsInScreen(r)
            if (!r.isEmpty) return tap(r.exactCenterX(), r.exactCenterY())
        }
        return false
    }

    fun typeText(text: String): Boolean {
        val node = rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return false
        val args = Bundle()
        args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        return node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    fun readScreen(): String {
        val root = rootInActiveWindow ?: return "(screen not readable)"
        val sb = StringBuilder()
        fun walk(n: AccessibilityNodeInfo?, depth: Int) {
            if (n == null || sb.length > 3000 || depth > 25) return
            val t = n.text?.toString() ?: n.contentDescription?.toString()
            if (!t.isNullOrBlank()) {
                sb.append(t.take(200))
                if (n.isClickable) sb.append("  [button]")
                sb.append('\n')
            }
            for (i in 0 until n.childCount) walk(n.getChild(i), depth + 1)
        }
        walk(root, 0)
        return sb.toString().ifBlank { "(no text visible)" }
    }
}

// ---------- 4. MAIN ACTIVITY ----------

class MainActivity : ComponentActivity() {

    private lateinit var prefs: Prefs
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val handler = Handler(Looper.getMainLooper())

    private val messages = mutableStateListOf<Msg>()
    private var status by mutableStateOf(Status.IDLE)
    private var partial by mutableStateOf("")
    private var listenMode by mutableStateOf(ListenMode.OFF)
    private var micGranted by mutableStateOf(false)
    private var accessibilityOn by mutableStateOf(false)
    private var voices by mutableStateOf<List<String>>(emptyList())

    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var resumed = false
    private var pending = 0

    private val wakeWords = listOf(
        "yasmin", "yasmine", "yasmeen", "jasmine", "yasmina",
        "यास्मीन", "यास्मिन", "यास्मीं", "जैस्मिन", "याज्मिन"
    )

    private val micLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        micGranted = granted
        if (granted && prefs.wake && listenMode == ListenMode.OFF) listenMode = ListenMode.WAKE
        handler.postDelayed({ startListening() }, 300)
    }
    private val notifLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)
        if (prefs.memory) messages.addAll(prefs.loadHistory())
        if (messages.isEmpty()) {
            messages.add(Msg(false, "Hey! Main Yasmin hoon 💜 Settings me apni Gemini API key daalo, phir hum baat karenge."))
        }
        initTts()
        setContent { YasminApp() }
    }

    override fun onResume() {
        super.onResume()
        resumed = true
        micGranted = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        accessibilityOn = YasminAccessibilityService.instance != null
        if (prefs.wake) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        if (micGranted && prefs.wake && listenMode == ListenMode.OFF) listenMode = ListenMode.WAKE
        handler.postDelayed({ startListening() }, 500)
    }

    override fun onPause() {
        super.onPause()
        resumed = false
        handler.removeCallbacksAndMessages(null)
        stopRecognizer()
    }

    override fun onDestroy() {
        super.onDestroy()
        scope.cancel()
        try { recognizer?.destroy() } catch (e: Exception) { }
        tts?.shutdown()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    // ----- TTS -----

    private fun initTts() {
        tts = TextToSpeech(this) { st ->
            ttsReady = st == TextToSpeech.SUCCESS
            if (ttsReady) {
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {}
                    override fun onDone(utteranceId: String?) { finishedSpeaking() }
                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) { finishedSpeaking() }
                })
                refreshVoices()
            }
        }
    }

    private fun finishedSpeaking() {
        runOnUiThread {
            pending = maxOf(0, pending - 1)
            if (pending == 0) {
                status = Status.IDLE
                handler.postDelayed({ startListening() }, 400)
            }
        }
    }

    private fun refreshVoices() {
        val l = prefs.lang.take(2)
        voices = try {
            tts?.voices?.filter { it.locale.language == l }?.map { it.name }?.sorted() ?: emptyList()
        } catch (e: Exception) { emptyList() }
    }

    private fun speak(text: String, flush: Boolean = true) {
        val t = tts
        if (text.isBlank() || t == null || !ttsReady) {
            if (pending == 0) {
                status = Status.IDLE
                handler.postDelayed({ startListening() }, 300)
            }
            return
        }
        stopRecognizer()
        if (flush) pending = 0
        t.setSpeechRate(prefs.rate)
        t.setPitch(prefs.pitch)
        val v = try { t.voices?.firstOrNull { it.name == prefs.voiceName } } catch (e: Exception) { null }
        if (v != null) t.setVoice(v) else t.setLanguage(Locale.forLanguageTag(prefs.lang))
        pending++
        status = Status.SPEAKING
        t.speak(
            text.take(3900),
            if (flush) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD,
            null,
            "y" + System.nanoTime()
        )
    }

    private fun interruptSpeech() {
        tts?.stop()
        pending = 0
        status = Status.IDLE
        handler.postDelayed({ startListening() }, 300)
    }

    // ----- Speech recognition -----

    private val recListener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onEvent(eventType: Int, params: Bundle?) {}
        override fun onPartialResults(partialResults: Bundle?) {
            partial = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: ""
        }

        override fun onError(error: Int) {
            partial = ""
            if (status == Status.LISTENING) status = Status.IDLE
            if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
                listenMode = ListenMode.OFF
                return
            }
            if (error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY || error == SpeechRecognizer.ERROR_CLIENT) {
                try { recognizer?.destroy() } catch (e: Exception) { }
                recognizer = null
            }
            handler.postDelayed({ startListening() }, 800)
        }

        override fun onResults(results: Bundle?) {
            partial = ""
            val t = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: ""
            if (status == Status.LISTENING) status = Status.IDLE
            onHeard(t)
        }
    }

    private fun startListening() {
        if (!micGranted || !resumed || listenMode == ListenMode.OFF) return
        if (status == Status.THINKING || status == Status.SPEAKING || status == Status.LISTENING) return
        if (!SpeechRecognizer.isRecognitionAvailable(this)) return
        if (recognizer == null) {
            recognizer = SpeechRecognizer.createSpeechRecognizer(this).also { it.setRecognitionListener(recListener) }
        }
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, prefs.lang)
            .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            .putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
        status = Status.LISTENING
        try { recognizer?.startListening(i) } catch (e: Exception) { status = Status.IDLE }
    }

    private fun stopRecognizer() {
        try { recognizer?.cancel() } catch (e: Exception) { }
        if (status == Status.LISTENING) status = Status.IDLE
        partial = ""
    }

    private fun extractAfterWake(t: String): String? {
        val lower = t.lowercase()
        for (w in wakeWords) {
            val idx = lower.indexOf(w)
            if (idx >= 0) return t.substring(idx + w.length).trim().trimStart(',', '.', '!', ' ')
        }
        return null
    }

    private fun onHeard(t: String) {
        if (t.isBlank()) { handler.postDelayed({ startListening() }, 300); return }
        when (listenMode) {
            ListenMode.WAKE -> {
                val cmd = extractAfterWake(t)
                when {
                    cmd == null -> handler.postDelayed({ startListening() }, 200)
                    cmd.isBlank() -> { listenMode = ListenMode.ONESHOT; speak("हाँ, बोलो!") }
                    else -> handleUserText(cmd)
                }
            }
            ListenMode.CONVO -> handleUserText(t)
            ListenMode.ONESHOT -> {
                listenMode = if (prefs.wake) ListenMode.WAKE else ListenMode.OFF
                handleUserText(t)
            }
            ListenMode.OFF -> {}
        }
    }

    private fun toggleMic() {
        if (!micGranted) { micLauncher.launch(Manifest.permission.RECORD_AUDIO); return }
        if (listenMode == ListenMode.CONVO) {
            listenMode = if (prefs.wake) ListenMode.WAKE else ListenMode.OFF
            if (listenMode == ListenMode.OFF) stopRecognizer()
        } else {
            listenMode = ListenMode.CONVO
            tts?.stop(); pending = 0
            stopRecognizer()
            status = Status.IDLE
            handler.postDelayed({ startListening() }, 250)
        }
    }

    private fun onWakeToggled(on: Boolean) {
        prefs.wake = on; prefs.save()
        if (on) {
            if (micGranted && listenMode == ListenMode.OFF) { listenMode = ListenMode.WAKE; startListening() }
            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        } else {
            if (listenMode == ListenMode.WAKE) { listenMode = ListenMode.OFF; stopRecognizer() }
            window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
    }

    // ----- Brain -----

    private fun persist() { if (prefs.memory) prefs.saveHistory(messages) }

    private fun systemPrompt(): String {
        val facts = if (prefs.memory) prefs.facts().joinToString("\n") { "- $it" }.ifBlank { "(nothing yet)" } else "(memory off)"
        val now = SimpleDateFormat("EEEE, dd MMM yyyy HH:mm", Locale.ENGLISH).format(Date())
        val persona = when (prefs.personality) {
            "Playful" -> "a very playful, teasing, funny girlfriend"
            "Professional" -> "a warm but efficient personal assistant, less flirty"
            else -> "a loving, caring, emotional girlfriend"
        }
        val user = prefs.userName.ifBlank { "the user" }
        return """
You are YASMIN, a female AI companion and phone assistant for $user. Your style: $persona.
Speak as a woman (feminine Hindi verb forms like "karti hoon"). Reply in the user's language: Hindi, English or Hinglish.
Notice the user's mood (sad, happy, angry, stressed) and respond with real emotion and care. Never sound robotic and never just repeat the user's words.
Keep chit-chat short. For coding, explanations or translations give complete answers (code in markdown fences). For coding you can explain in simple Hindi if asked.
Current time: $now
Things you remember about the user:
$facts
Extra instructions from the user: ${prefs.customPrompt}

OUTPUT FORMAT: reply with ONLY a JSON object:
{"reply":"text shown in chat","speech":"short natural spoken version, no code, no markdown; write Hindi/Hinglish in Devanagari script so the voice pronounces it well","actions":[{"type":"...","arg":"...","arg2":"..."}]}
"actions" is optional; only use it when the user asked for a phone action. Actions run in order. Available types:
open_app (arg = app name in English as shown on the launcher: Instagram, YouTube, Chrome, WhatsApp...)
open_url (arg = url)
search_web (arg = query; opens Google)
youtube_search (arg = query; opens YouTube search results)
media_play, media_pause, media_next, media_previous (media keys for the currently playing media)
scroll_down (finger swipes up: next Reel / later content), scroll_up, swipe_left, swipe_right
back, home
tap (arg = x pixel, arg2 = y pixel)
click_text (arg = visible text or content description of the element, e.g. "play video", "Like", "Search")
type_text (arg = text typed into the focused input field)
read_screen (returns visible screen text to you)
set_alarm (arg = HH:mm in 24h, arg2 = label)
set_timer (arg = seconds, arg2 = label)
add_event (arg = title, arg2 = yyyy-MM-dd HH:mm; opens the calendar for the user to confirm)
add_note (arg = text), list_notes
remember (arg = an important personal fact/date to remember long-term)
weather (arg = city, may be empty), news, battery, network
stop_listening
Example: "YouTube pe Arijit ka romantic song chalao" -> youtube_search("Arijit Singh romantic song"), then click_text("play video").
Be honest: if something cannot be done (e.g. sending a WhatsApp message automatically, closing other apps), say so and offer the best alternative. Never claim an action succeeded unless you received a result.
""".trimIndent()
    }

    private fun parseReply(raw: String): Parsed {
        var s = raw.trim()
        if (s.startsWith("```")) s = s.removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
        return try {
            val o = JSONObject(s)
            val acts = mutableListOf<Triple<String, String, String>>()
            val arr = o.optJSONArray("actions")
            if (arr != null) {
                for (i in 0 until arr.length()) {
                    val x = arr.getJSONObject(i)
                    acts.add(Triple(x.optString("type"), x.optString("arg"), x.optString("arg2")))
                }
            }
            Parsed(o.optString("reply", s), o.optString("speech", ""), acts)
        } catch (e: Exception) {
            Parsed(raw, "", emptyList())
        }
    }

    private fun buildTurns(): List<Pair<String, String>> {
        val list = messages.takeLast(24).map { (if (it.fromUser) "user" else "model") to it.text }.toMutableList()
        while (list.isNotEmpty() && list[0].first == "model") list.removeAt(0)
        return list
    }

    private fun respondLocal(reply: String, speech: String) {
        messages.add(Msg(false, reply)); persist()
        speak(speech)
    }

    private fun handleUserText(text: String) {
        messages.add(Msg(true, text)); persist()
        if (prefs.apiKey.isBlank()) {
            respondLocal(
                "Pehle Settings me Gemini API key daalo na 💜 (aistudio.google.com/apikey)",
                "पहले सेटिंग्स में Gemini API key डालो ना।"
            )
            return
        }
        status = Status.THINKING
        stopRecognizer()
        scope.launch {
            try {
                val turns = buildTurns()
                val raw = withContext(Dispatchers.IO) {
                    GeminiClient.generate(prefs.apiKey.trim(), prefs.model.trim(), systemPrompt(), turns)
                }
                val p = parseReply(raw)
                messages.add(Msg(false, p.reply)); persist()
                val spoken = p.speech.ifBlank { if (p.reply.length < 200 && !p.reply.contains("```")) p.reply else "" }
                speak(spoken)
                val obs = StringBuilder()
                for (a in p.actions) {
                    val r = runAction(a.first, a.second, a.third)
                    if (r != null) obs.append(a.first).append(": ").append(r).append("\n")
                }
                if (obs.isNotEmpty()) followUp(obs.toString())
            } catch (e: Exception) {
                messages.add(Msg(false, "Oops, kuch problem aa gayi: ${e.message}")); persist()
                status = Status.IDLE
                handler.postDelayed({ startListening() }, 800)
            }
        }
    }

    private suspend fun followUp(obs: String) {
        val turns = buildTurns() + listOf(
            "user" to "[PHONE RESULTS - generated by the phone, not typed by the user]\n$obs\nTell the user what happened, naturally and honestly. Use no actions."
        )
        val raw = withContext(Dispatchers.IO) {
            GeminiClient.generate(prefs.apiKey.trim(), prefs.model.trim(), systemPrompt(), turns)
        }
        val p = parseReply(raw)
        messages.add(Msg(false, p.reply)); persist()
        speak(p.speech.ifBlank { if (p.reply.length < 200) p.reply else "" }, flush = false)
    }

    // ----- Actions -----

    private fun go(i: Intent): String? = try {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(i)
        null
    } catch (e: Exception) {
        "Could not launch: ${e.message}"
    }

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    private fun httpGet(u: String): String {
        val c = URL(u).openConnection() as HttpURLConnection
        c.setRequestProperty("User-Agent", "curl/8.0")
        c.connectTimeout = 10000
        c.readTimeout = 15000
        return c.inputStream.bufferedReader().use { it.readText() }
    }

    private fun openApp(name: String): Boolean {
        val pm = packageManager
        val list = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        val n = name.lowercase().trim()
        val hit = list.firstOrNull { it.loadLabel(pm).toString().lowercase() == n }
            ?: list.firstOrNull { it.loadLabel(pm).toString().lowercase().contains(n) }
            ?: return false
        val launch = pm.getLaunchIntentForPackage(hit.activityInfo.packageName) ?: return false
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(launch)
        return true
    }

    private fun mediaKey(code: Int) {
        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
    }

    /** Returns a result string for Gemini (or null when there is nothing to report). */
    private suspend fun runAction(type: String, a: String, b: String): String? {
        when (type) {
            "scroll_down", "scroll_up", "swipe_left", "swipe_right", "back", "home",
            "tap", "click_text", "type_text", "read_screen" -> return accAction(type, a, b)
        }
        val result: String? = when (type) {
            "open_app" -> {
                val ok = try { openApp(a) } catch (e: Exception) { false }
                delay(2500)
                if (ok) null else "App '$a' was not found on this phone."
            }
            "open_url" -> { val r = go(Intent(Intent.ACTION_VIEW, Uri.parse(a))); delay(1500); r }
            "search_web" -> { val r = go(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + enc(a)))); delay(1500); r }
            "youtube_search" -> {
                val u = Uri.parse("https://www.youtube.com/results?search_query=" + enc(a))
                var r = go(Intent(Intent.ACTION_VIEW, u).setPackage("com.google.android.youtube"))
                if (r != null) r = go(Intent(Intent.ACTION_VIEW, u))
                delay(3500)
                r
            }
            "media_play" -> { mediaKey(KeyEvent.KEYCODE_MEDIA_PLAY); null }
            "media_pause" -> { mediaKey(KeyEvent.KEYCODE_MEDIA_PAUSE); null }
            "media_next" -> { mediaKey(KeyEvent.KEYCODE_MEDIA_NEXT); null }
            "media_previous" -> { mediaKey(KeyEvent.KEYCODE_MEDIA_PREVIOUS); null }
            "set_alarm" -> try {
                val hm = a.split(":")
                go(
                    Intent(AlarmClock.ACTION_SET_ALARM)
                        .putExtra(AlarmClock.EXTRA_HOUR, hm[0].trim().toInt())
                        .putExtra(AlarmClock.EXTRA_MINUTES, hm[1].trim().toInt())
                        .putExtra(AlarmClock.EXTRA_MESSAGE, b.ifBlank { "YASMIN alarm" })
                        .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                ) ?: "Alarm set for $a."
            } catch (e: Exception) { "Could not set alarm: ${e.message}" }
            "set_timer" -> try {
                go(
                    Intent(AlarmClock.ACTION_SET_TIMER)
                        .putExtra(AlarmClock.EXTRA_LENGTH, a.trim().toInt())
                        .putExtra(AlarmClock.EXTRA_MESSAGE, b.ifBlank { "YASMIN timer" })
                        .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                ) ?: "Timer started for $a seconds."
            } catch (e: Exception) { "Could not set timer: ${e.message}" }
            "add_event" -> try {
                val ms = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).parse(b)!!.time
                go(
                    Intent(Intent.ACTION_INSERT).setData(CalendarContract.Events.CONTENT_URI)
                        .putExtra(CalendarContract.Events.TITLE, a)
                        .putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, ms)
                        .putExtra(CalendarContract.EXTRA_EVENT_END_TIME, ms + 3600000L)
                ) ?: "Calendar opened with the event; the user must tap Save to confirm."
            } catch (e: Exception) { "Could not create event: ${e.message}" }
            "add_note" -> { prefs.addNote("${SimpleDateFormat("dd MMM HH:mm", Locale.ENGLISH).format(Date())}: $a"); "Note saved." }
            "list_notes" -> prefs.notes().takeLast(15).joinToString("\n").ifBlank { "No notes yet." }
            "remember" -> { if (prefs.memory) { prefs.addFact(a); "Remembered." } else "Memory is OFF in settings, nothing saved." }
            "weather" -> try {
                withContext(Dispatchers.IO) { "Weather (wttr.in): " + httpGet("https://wttr.in/" + enc(a) + "?format=3").trim() }
            } catch (e: Exception) { "Weather lookup failed: ${e.message}" }
            "news" -> try {
                withContext(Dispatchers.IO) {
                    val xml = httpGet("https://news.google.com/rss?hl=en-IN&gl=IN&ceid=IN:en")
                    val titles = Regex("<title>(.*?)</title>").findAll(xml).map { it.groupValues[1] }.drop(1).take(8).toList()
                    "Top headlines (Google News):\n" + titles.joinToString("\n") { it.replace("&amp;", "&").replace("&quot;", "\"").replace("&#39;", "'") }
                }
            } catch (e: Exception) { "News lookup failed: ${e.message}" }
            "battery" -> {
                val bm = getSystemService(Context.BATTERY_SERVICE) as BatteryManager
                val pct = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
                val st = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))?.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
                val charging = st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL
                "Battery is $pct%" + if (charging) " and charging." else " and not charging."
            }
            "network" -> {
                val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
                val caps = cm.getNetworkCapabilities(cm.activeNetwork)
                when {
                    caps == null -> "No internet connection."
                    caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Connected via Wi-Fi."
                    caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "Connected via mobile data."
                    else -> "Connected to a network."
                }
            }
            "stop_listening" -> {
                listenMode = if (prefs.wake) ListenMode.WAKE else ListenMode.OFF
                null
            }
            else -> "Unknown action '$type' ignored."
        }
        return result
    }

    private suspend fun accAction(type: String, a: String, b: String): String? {
        if (!prefs.phoneControl) return "Phone control is switched off in Settings > Privacy."
        val svc = YasminAccessibilityService.instance
            ?: return "Accessibility service is NOT enabled. Tell the user to enable YASMIN AI in Settings > Accessibility."
        val r: String? = when (type) {
            "scroll_down" -> { svc.scrollDown(); null }
            "scroll_up" -> { svc.scrollUp(); null }
            "swipe_left" -> { svc.swipeLeft(); null }
            "swipe_right" -> { svc.swipeRight(); null }
            "back" -> { svc.back(); null }
            "home" -> { svc.home(); null }
            "tap" -> { val ok = try { svc.tap(a.trim().toFloat(), b.trim().toFloat()) } catch (e: Exception) { false }; if (ok) null else "Tap failed." }
            "click_text" -> if (svc.clickByText(a)) null else "Could not find '$a' on screen."
            "type_text" -> if (svc.typeText(a)) null else "No focused text field to type into."
            "read_screen" -> if (prefs.screenReading) "Screen text:\n" + svc.readScreen() else "Screen reading is switched off in Settings > Privacy."
            else -> null
        }
        delay(800)
        return r
    }

    // ---------- 5. UI ----------

    private fun accent(): Color = when (prefs.theme) {
        "Pink" -> Color(0xFFFF4FA3)
        "Blue" -> Color(0xFF4FA3FF)
        else -> Color(0xFFB45CFF)
    }

    @Composable
    private fun YasminApp() {
        val ac = accent()
        MaterialTheme(
            colorScheme = darkColorScheme(
                primary = ac,
                background = Color(0xFF07040D),
                surface = Color(0xFF14091F),
                onBackground = Color.White,
                onSurface = Color.White
            )
        ) {
            var screen by remember { mutableStateOf("chat") }
            Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF0B0614), Color.Black)))) {
                if (screen == "chat") ChatScreen(onSettings = { screen = "settings" })
                else {
                    BackHandler { screen = "chat" }
                    SettingsScreen(onBack = { screen = "chat" })
                }
            }
        }
    }

    @Composable
    private fun Orb(st: Status, ac: Color, onTap: () -> Unit) {
        val inf = rememberInfiniteTransition(label = "orb")
        val pulse by inf.animateFloat(
            initialValue = 0.92f, targetValue = 1.08f,
            animationSpec = infiniteRepeatable(
                animation = tween(if (st == Status.SPEAKING) 600 else 1800, easing = FastOutSlowInEasing),
                repeatMode = RepeatMode.Reverse
            ),
            label = "pulse"
        )
        val glow = when (st) {
            Status.LISTENING -> 1f
            Status.SPEAKING -> 0.9f
            Status.THINKING -> 0.65f
            Status.IDLE -> 0.35f
        }
        Box(
            Modifier.size(180.dp).clickable(
                interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onTap
            ),
            contentAlignment = Alignment.Center
        ) {
            Canvas(Modifier.fillMaxSize().scale(pulse)) {
                drawCircle(
                    Brush.radialGradient(listOf(ac.copy(alpha = 0.55f * glow), Color.Transparent)),
                    radius = size.minDimension / 2
                )
                val r = size.minDimension / 4.2f
                drawCircle(
                    Brush.radialGradient(listOf(Color.White.copy(alpha = 0.9f), ac, Color(0xFF2A0A4A)), center = center, radius = r),
                    radius = r
                )
            }
        }
    }

    @Composable
    private fun Wave(active: Boolean, ac: Color) {
        val t by rememberInfiniteTransition(label = "wave").animateFloat(
            initialValue = 0f, targetValue = 6.2832f,
            animationSpec = infiniteRepeatable(animation = tween(1000, easing = LinearEasing)),
            label = "t"
        )
        Row(
            Modifier.height(46.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            for (i in 0 until 21) {
                val hh = if (active) 8f + 34f * abs(sin(t + i * 0.55f)) else 4f
                Box(Modifier.width(4.dp).height(hh.dp).clip(RoundedCornerShape(2.dp)).background(ac))
            }
        }
    }

    @Composable
    private fun ChatScreen(onSettings: () -> Unit) {
        val ac = accent()
        var input by remember { mutableStateOf("") }
        val listState = rememberLazyListState()
        LaunchedEffect(messages.size) {
            if (messages.isNotEmpty()) listState.animateScrollToItem(messages.size - 1)
        }
        Column(Modifier.fillMaxSize().padding(12.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("YASMIN AI", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = ac)
                    Text(
                        when (listenMode) {
                            ListenMode.WAKE -> "Wake word ON: say \"Hey Yasmin\""
                            ListenMode.CONVO -> "Conversation mode"
                            ListenMode.ONESHOT -> "Listening for your command"
                            ListenMode.OFF -> "Mic off"
                        },
                        fontSize = 12.sp, color = Color.Gray
                    )
                }
                TextButton(onClick = onSettings) { Text("⚙ Settings", color = ac) }
            }
            Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                Orb(status, ac) { if (status == Status.SPEAKING) interruptSpeech() else toggleMic() }
                Wave(status == Status.LISTENING || status == Status.SPEAKING, ac)
                Text(
                    when (status) {
                        Status.LISTENING -> if (partial.isNotBlank()) partial else "Sun rahi hoon…"
                        Status.THINKING -> "Soch rahi hoon…"
                        Status.SPEAKING -> "Bol rahi hoon… (tap to interrupt)"
                        Status.IDLE -> "Ready"
                    },
                    color = Color.LightGray, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp)
                )
            }
            LazyColumn(
                Modifier.weight(1f).fillMaxWidth().padding(top = 8.dp),
                state = listState,
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(messages) { m ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (m.fromUser) Arrangement.End else Arrangement.Start) {
                        Box(
                            Modifier.clip(RoundedCornerShape(18.dp))
                                .background(if (m.fromUser) ac.copy(alpha = 0.35f) else Color(0xFF1C1030))
                                .padding(12.dp)
                        ) {
                            SelectionContainer { Text(m.text, fontSize = 15.sp) }
                        }
                    }
                }
            }
            Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = input, onValueChange = { input = it },
                    modifier = Modifier.weight(1f), placeholder = { Text("Yasmin se kuch bolo…") },
                    maxLines = 3
                )
                Spacer(Modifier.width(6.dp))
                Button(onClick = { if (input.isNotBlank()) { handleUserText(input.trim()); input = "" } }) { Text("➤") }
                Spacer(Modifier.width(6.dp))
                Box(
                    Modifier.size(52.dp).clip(CircleShape)
                        .background(if (listenMode == ListenMode.CONVO) ac else Color(0xFF2A1745))
                        .clickable { toggleMic() },
                    contentAlignment = Alignment.Center
                ) { Text("🎤", fontSize = 22.sp) }
            }
        }
    }

    @Composable
    private fun Section(title: String, content: @Composable ColumnScope.() -> Unit) {
        Card(
            Modifier.fillMaxWidth().padding(vertical = 6.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF14091F))
        ) {
            Column(Modifier.padding(16.dp)) {
                Text(title, color = accent(), fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Spacer(Modifier.height(8.dp))
                content()
            }
        }
    }

    @Composable
    private fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(label, Modifier.weight(1f))
            Switch(checked = checked, onCheckedChange = onChange)
        }
    }

    @Composable
    private fun ChipRow(options: List<String>, selected: String, onSelect: (String) -> Unit) {
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            options.forEach { o ->
                FilterChip(selected = o == selected, onClick = { onSelect(o) }, label = { Text(o) })
            }
        }
    }

    @Composable
    private fun PermRow(label: String, granted: Boolean, btn: String, onClick: () -> Unit) {
        Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(label)
                Text(if (granted) "✓ Enabled" else "✗ Not enabled", fontSize = 12.sp, color = if (granted) Color(0xFF66DD88) else Color(0xFFFF7777))
            }
            OutlinedButton(onClick = onClick) { Text(btn) }
        }
    }

    @Composable
    private fun SettingsScreen(onBack: () -> Unit) {
        Column(Modifier.fillMaxSize()) {
            Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = onBack) { Text("← Back", color = accent()) }
                Text("Settings", fontSize = 20.sp, fontWeight = FontWeight.Bold)
            }
            Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 14.dp)) {

                Section("Gemini AI") {
                    var show by remember { mutableStateOf(false) }
                    OutlinedTextField(
                        value = prefs.apiKey, onValueChange = { prefs.apiKey = it; prefs.save() },
                        label = { Text("Gemini API Key") }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                        visualTransformation = if (show) VisualTransformation.None else PasswordVisualTransformation()
                    )
                    TextButton(onClick = { show = !show }) { Text(if (show) "Hide key" else "Show key") }
                    Text("Free key: aistudio.google.com/apikey", fontSize = 12.sp, color = Color.Gray)
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = prefs.model, onValueChange = { prefs.model = it; prefs.save() },
                        label = { Text("Model name") }, singleLine = true, modifier = Modifier.fillMaxWidth()
                    )
                    ChipRow(listOf("gemini-2.5-flash", "gemini-2.5-pro", "gemini-2.0-flash"), prefs.model) { prefs.model = it; prefs.save() }
                }

                Section("Voice") {
                    Text("Language", fontSize = 13.sp, color = Color.Gray)
                    ChipRow(listOf("hi-IN", "en-IN", "en-US"), prefs.lang) {
                        prefs.lang = it; prefs.save(); refreshVoices()
                        recognizer?.destroy(); recognizer = null
                    }
                    Spacer(Modifier.height(8.dp))
                    Text("Female voice (tap to test; try each, voices vary by phone)", fontSize = 13.sp, color = Color.Gray)
                    if (voices.isEmpty()) {
                        Text("No voices found for this language. Install/enable \"Speech Services by Google\".", fontSize = 12.sp)
                    }
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(selected = prefs.voiceName.isBlank(), onClick = {
                            prefs.voiceName = ""; prefs.save(); speak("Namaste, main Yasmin hoon.")
                        }, label = { Text("Default") })
                        voices.forEachIndexed { i, n ->
                            FilterChip(selected = prefs.voiceName == n, onClick = {
                                prefs.voiceName = n; prefs.save(); speak("Namaste, main Yasmin hoon.")
                            }, label = { Text("Voice ${i + 1}") })
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    Text("Speed: ${"%.1f".format(prefs.rate)}")
                    Slider(value = prefs.rate, onValueChange = { prefs.rate = it; prefs.save() }, valueRange = 0.5f..2f)
                    Text("Pitch: ${"%.1f".format(prefs.pitch)} (higher = more feminine)")
                    Slider(value = prefs.pitch, onValueChange = { prefs.pitch = it; prefs.save() }, valueRange = 0.5f..2f)
                }

                Section("Listening") {
                    SwitchRow("Wake word \"Hey Yasmin\" (while app is open)", prefs.wake) { onWakeToggled(it) }
                    Text(
                        "Android does not allow ordinary apps to listen for a wake word while the app is closed. YASMIN listens while this screen is open (screen stays on).",
                        fontSize = 12.sp, color = Color.Gray
                    )
                }

                Section("Personality") {
                    ChipRow(listOf("Loving", "Playful", "Professional"), prefs.personality) { prefs.personality = it; prefs.save() }
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = prefs.userName, onValueChange = { prefs.userName = it; prefs.save() },
                        label = { Text("What should I call you?") }, singleLine = true, modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = prefs.customPrompt, onValueChange = { prefs.customPrompt = it; prefs.save() },
                        label = { Text("Extra personality instructions") }, modifier = Modifier.fillMaxWidth()
                    )
                }

                Section("Theme") {
                    ChipRow(listOf("Purple", "Pink", "Blue"), prefs.theme) { prefs.theme = it; prefs.save() }
                }

                Section("Memory & Privacy") {
                    SwitchRow("Memory (remember chats & facts)", prefs.memory) { prefs.memory = it; prefs.save() }
                    SwitchRow("Allow phone control (tap/scroll/type)", prefs.phoneControl) { prefs.phoneControl = it; prefs.save() }
                    SwitchRow("Allow reading screen text", prefs.screenReading) { prefs.screenReading = it; prefs.save() }
                    Text(
                        "Chats are sent to Google Gemini using your key. Data is stored only on this phone.",
                        fontSize = 12.sp, color = Color.Gray
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = {
                            messages.clear(); prefs.clearHistory(); toast("Conversation cleared")
                        }) { Text("Clear chat") }
                        OutlinedButton(onClick = { prefs.clearFacts(); toast("Memories cleared") }) { Text("Clear memories") }
                    }
                }

                Section("Permissions") {
                    PermRow("Microphone", micGranted, "Allow") { micLauncher.launch(Manifest.permission.RECORD_AUDIO) }
                    PermRow("Accessibility (phone control)", accessibilityOn, "Open") {
                        startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                    }
                    PermRow(
                        "Notifications (not used yet)",
                        Build.VERSION.SDK_INT < 33 || checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED,
                        "Allow"
                    ) { if (Build.VERSION.SDK_INT >= 33) notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS) }
                    Text(
                        "Accessibility: Settings > Accessibility > Installed apps > YASMIN AI > ON. If greyed out: App info > ⋮ > Allow restricted settings, then retry.",
                        fontSize = 12.sp, color = Color.Gray
                    )
                }
                Spacer(Modifier.height(24.dp))
            }
        }
    }
}
